angular.module('persistentOLXApp', ['ui.router', 'ngSanitize', 'searchBox', 'productDetails', 'sellerInformation', 'productDescription', 'productSpecifications', 'ngAnimate', 'ui.bootstrap'])
    .config(function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/home');
        $stateProvider
            .state('home', {
                url: '/home',
                controller: 'productDetailsController'
            })
            .state('productDetails', {
                url: '/productDetails',
                templateUrl: 'templates/productDetails.html',
                controller: 'productDetailsController'
            })
            .state('sellerInformation', {
                url: '/sellerInformation',
                templateUrl: 'templates/sellerInformation.html',
                controller: 'sellerInformationController'
            });
    }).run(function ($rootScope, $state) {
    $rootScope.$state = $state;
});