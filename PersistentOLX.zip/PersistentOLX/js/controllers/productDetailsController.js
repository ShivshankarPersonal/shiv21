angular.module('persistentOLXApp')
    .controller('productDetailsController', function ($scope, $state, persistentOLXFactory) {
        var data = persistentOLXFactory.itemDetails;
        $scope.name = data.name;
        $scope.description = data.description;
        $scope.images = data.images;
        $scope.additionalFeatures = data.additionalFeatures;
        $scope.android = data.android;
        $scope.availability = data.availability;
        $scope.battery = data.battery;
        $scope.camera = data.camera;
        $scope.connectivity = data.connectivity;
        $scope.display = data.display;
        $scope.hardware = data.hardware;
        $scope.id = data.id;
        $scope.sizeAndWeight = data.sizeAndWeight;
        $scope.storage = data.storage;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    });